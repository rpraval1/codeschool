"""

"""
import pandas as pd

import numpy as np

class Indicators(object):

    def __init__(self):
        self.lt_av = [] #exponentially smoothed long term moving average  (smoothing window = 4 weeks, though flexible based on user input)
        self.st_av = [] #exponentially smoothed short term moving average (smoothing window = 2 weeks, though flexible based on user input)
        self.diff_ltst = [] #difference between ltav and stav
        self.diff_ltst_av = [] #exponentially smoothed moving average of diff_ltst (smoothing window = 1.5 weeks)
        self.diff_av_diff = [] #difference between diff_ltst and diff_ltst_av

    def sma(self, data, window):
        """
        Calculates Simple Moving Average
        http://fxtrade.oanda.com/learn/forex-indicators/simple-moving-average
        """
        if len(data) < window:
            return None
        return sum(data[-window:]) / float(window)

    # def ema(self, data, window, position=None, previous_ema=None):
    #     """
    #     Calculates Exponential Moving Average
    #     http://fxtrade.oanda.com/learn/forex-indicators/exponential-moving-average
    #     """
    #     if len(data) < window + 2:
    #         return None
    #     c = 2 / float(window + 1)
    #     if not previous_ema:
    #         return self.ema(data, window, window, self.sma(data[-window*2 + 1:-window + 1], window))
    #     else:
    #         current_ema = (c * data[-position]) + ((1 - c) * previous_ema)
    #         if position > 0:
    #             return self.ema(data, window, position - 1, current_ema)
    #         return previous_ema

    def ema(self, data, window, resultList,previous_ema):
        if len(data) < window:
            #return
            raise ValueError("data is too short"+str(len(data)))
        c = 2.0 / (window + 1)
        if not previous_ema:
            current_ema = self.sma(data[-window*2:-window], window)
        else:
            current_ema = previous_ema
        #resultList.append(current_ema)
        last_loop = False
        last_loop_counter = 0

        if(len(data) < 2 * window):
            print(str(len(data)))
            last_loop = True
            last_loop_counter = len(data)
        for value in data[-window:]:
            if(last_loop):
                last_loop_counter -= 1

            current_ema = (c * value) + ((1 - c) * current_ema)
            resultList.append(float(format(current_ema, '.2f')))
            if(last_loop_counter == window):
                break
            #print(i)
        return resultList

    def calculateEMA(self,data,window,resultList):
        remaining_data = len(data)
        i = len(data)
        previous_ema = None
        while(remaining_data > window):
            self.ema(data[:i], window, resultList ,previous_ema)
            previous_ema = resultList[-1]
            remaining_data -= window
            i -= window

demo = Indicators()

# Read the data into a Pandas dataframe
df = pd.read_csv('goog.csv')
#print(df["Close"].head())
closeArray = df["Close"]
closeArray = closeArray[::-1]
#closeArr = closeArray[len(closeArray)-80:]
print(len(closeArray))
# print(closeArray[35])

demo.calculateEMA(closeArray,20,demo.lt_av)

demo.calculateEMA(closeArray,10,demo.st_av)

# print(demo.lt_av[:40])
# print(len(demo.lt_av))
#
# demo.ema(closeArray,20,demo.st_av,None)
# print(demo.st_av)
# print(len(demo.st_av))
#
# demo.st_av = []
# demo.ema(closeArray[1:len(closeArray)-1],20,demo.st_av,None)
#
# print(demo.st_av)
# print(len(demo.st_av))


arr1 = np.array(demo.lt_av)
arr2 = np.array(demo.st_av[:len(demo.lt_av)])

demo.diff_ltst =  list(np.subtract(arr1,arr2))
print(len(demo.diff_ltst))

items=[demo.lt_av,demo.st_av, demo.diff_ltst]

df = pd.DataFrame(items)
df = df.T
df.to_csv("myfile.csv",sep='\t',index=False,header=True)



# st_av = demo.ema1(closeArray, 10)
# diff_ltst = lt_av - st_av
#
# print(st_av)
#
# print(diff_ltst)
#
#
# st_av = demo.ema1(closeArray, 10)
